# freetype-windows-binaries
Windows binaries (DLL) of FreeType 2.7.1 (win32/win64)

Compiled with VS Express 2012

Compatible with Windows XP, Vista, 7, 8, 10


freetype271MT.dll use the static CRT

freetype271.dll use the dynamic CRT (require Visual C++ 2012 Redistribuable to be present on system)
